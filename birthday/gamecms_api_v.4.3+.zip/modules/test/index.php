<?
if(isset($_POST['install'])) {
	$pdo->exec("ALTER TABLE users ADD prefix VARCHAR( 30 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;");
	$pdo->exec("ALTER TABLE users ADD game_time int( 11 ) NOT NULL DEFAULT 0 ;");

	echo "Готово! База данных обновлена!";
	exit();
}
?>
<form action="" method="post">
	<input type="hidden" name="install" />
	<input type="submit" value="Установить обнову для GameCMS_API" />
</form>